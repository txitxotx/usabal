-- ──────────────────────────────────────────────────────────────────────────────
-- AquaDash · Socorrista — Tablas: intervenciones + aforo
-- ──────────────────────────────────────────────────────────────────────────────
-- Cómo aplicar:
--   Supabase Dashboard → SQL Editor → pega todo y "Run"
-- ──────────────────────────────────────────────────────────────────────────────

-- 1) INTERVENCIONES (curas, mareos, desmayos, etc.)
CREATE TABLE IF NOT EXISTS socorrista_intervenciones (
  id              TEXT PRIMARY KEY,
  fecha_hora      TIMESTAMPTZ NOT NULL,
  edad_paciente   INT,
  motivo          TEXT NOT NULL,
  actuacion       TEXT NOT NULL,
  materiales      TEXT,
  nota_final      TEXT,
  socorrista_id   TEXT,
  socorrista_name TEXT NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_intervenciones_fecha
  ON socorrista_intervenciones(fecha_hora DESC);

CREATE INDEX IF NOT EXISTS idx_intervenciones_socorrista
  ON socorrista_intervenciones(socorrista_name);

-- 2) AFORO POR HORA (7:00 a 22:00) por piscina/sauna
CREATE TABLE IF NOT EXISTS socorrista_aforo (
  id              TEXT PRIMARY KEY,
  date            DATE NOT NULL,
  hour            INT  NOT NULL CHECK (hour BETWEEN 7 AND 22),
  pool            TEXT NOT NULL,
  cantidad        INT  NOT NULL DEFAULT 0,
  socorrista_id   TEXT,
  socorrista_name TEXT,
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Una sola entrada por (día, hora, piscina)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'socorrista_aforo_unique_slot'
  ) THEN
    ALTER TABLE socorrista_aforo
      ADD CONSTRAINT socorrista_aforo_unique_slot UNIQUE (date, hour, pool);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_aforo_date ON socorrista_aforo(date DESC);
CREATE INDEX IF NOT EXISTS idx_aforo_pool ON socorrista_aforo(pool);

-- 3) Verificación
SELECT
  'socorrista_intervenciones' AS tabla,
  COUNT(*) AS filas
FROM socorrista_intervenciones
UNION ALL
SELECT 'socorrista_aforo', COUNT(*) FROM socorrista_aforo;
