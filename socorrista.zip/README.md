# AquaDash · Sección Socorrista

## Contenido del paquete

```
socorrista/
├── README.md                                           ← este archivo
├── apply-socorrista-patches.mjs                        ← script para modificar archivos existentes
├── sql/
│   └── SQL_MIGRATION_SOCORRISTA.sql                    ← crea las 2 tablas en Supabase
└── src/
    └── app/dashboard/socorrista/page.tsx               ← NUEVA página principal
```

## Lo que se añade

### Nueva sección **🚑 Socorrista** en el menú
Visible para: admin, supervisor, operario y socorrista.

### Pestaña 1: **🩹 Intervenciones**
- Botón "+ Nueva intervención" → formulario modal con:
  - Fecha y hora (precargada con la actual)
  - Edad del paciente
  - Motivo de la atención *
  - Actuación realizada *
  - Materiales utilizados
  - Nota final / cierre
  - Nombre del socorrista (auto-capturado de la sesión)
- Tabla ordenada por fecha descendente
- Búsqueda por texto libre (motivo, actuación, etc.)
- Filtros de fecha "desde / hasta"
- **Exportación a PDF** del listado filtrado

### Pestaña 2: **👥 Aforo**
- Selector de día (por defecto hoy)
- Tabla cuadriculada: filas = horas (07:00 a 22:00), columnas = piscinas activas + Sauna Seca 1 + Sauna Seca 2 + Sauna Húmeda + Terma
- Cada celda es editable (al cambiar de celda se guarda automáticamente)
- Totales por hora, por instalación y total del día
- Sólo el día actual es editable (admin puede editar días pasados)
- Botón "↓ Ver histórico" → tabla resumen + filtros de fecha + **exportación a PDF**

---

## Instalación (5 minutos)

### Pasos en GitHub Codespaces (recomendado)

1. Abre tu Codespace en GitHub.com → tu repo → **Code** → **Codespaces** → tu Codespace anterior (o crea uno nuevo).

2. Sube el ZIP del paquete arrastrando `socorrista.zip` al panel de archivos.

3. En la terminal del Codespace:

```bash
# Descomprimir el ZIP
unzip socorrista.zip

# Copiar la nueva página al sitio correcto
mkdir -p src/app/dashboard/socorrista
cp socorrista/src/app/dashboard/socorrista/page.tsx src/app/dashboard/socorrista/page.tsx

# Copiar el script y ejecutarlo
cp socorrista/apply-socorrista-patches.mjs .
node apply-socorrista-patches.mjs
```

4. Subir a GitHub:

```bash
git add .
git commit -m "feat: sección Socorrista con intervenciones y aforo"
git push
```

5. Ejecutar la migración SQL:
   - Ve a https://supabase.com/dashboard/project/rdhtrzgjhwasrculdwrj
   - SQL Editor → New query
   - Copia y pega el contenido de `socorrista/sql/SQL_MIGRATION_SOCORRISTA.sql`
   - Pulsa **Run**

6. Espera 1-2 minutos a que Vercel despliegue automáticamente. Recarga la app.

7. Entra como admin (o socorrista). En el menú lateral verás **🚑 Socorrista**.

---

## Notas técnicas

- **Permisos**: se añaden 2 nuevos (`view_socorrista`, `edit_socorrista`).
  - `admin`: todos
  - `supervisor`: view + edit
  - `operario`: view + edit
  - `socorrista`: view + edit (rol específico)
  - `readonly`, `sanidad`: sin acceso

- **Datos**:
  - Tabla `socorrista_intervenciones` — un registro por intervención.
  - Tabla `socorrista_aforo` — un registro por (día, hora, piscina). UNIQUE constraint en esos 3 campos para que el upsert funcione.

- **Eliminación**: sólo admin puede eliminar intervenciones individuales y limpiar días enteros del aforo.

- **PDFs**: se generan vía `window.print()` sobre HTML maquetado, igual que en el resto de la app (no hay dependencias nuevas).

- **Idempotencia**: el script puede ejecutarse varias veces sin problema. Hace backup `.bak` de cada archivo antes de modificarlo.

### Si algo va mal
```bash
find src -name "*.bak" -exec sh -c 'mv "$1" "${1%.bak}"' _ {} \;
```
Eso restaura todos los archivos al estado original.
